package com.mustycodified.ewalletAPIwithspringbootandMongoDB.enums;

public enum TransactionStatus {

    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
}
