package com.mustycodified.ewalletAPIwithspringbootandMongoDB.enums;

public enum Status {

    ACTIVE, INACTIVE
}
